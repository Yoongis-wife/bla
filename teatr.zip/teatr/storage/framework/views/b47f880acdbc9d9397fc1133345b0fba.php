<?php $__env->startSection('content'); ?>
<div class="d-grid">
    <h1>Корзина</h1>
    <?php if($productions!=null): ?>
<div class="album py-5">
    <div class="container">
      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
<?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col">
    <div class="card">
            <div><?php echo e($production['product'][0]['name']); ?></div>
            <img src="../../images/<?php echo e($production['product'][0]['img']); ?>" >
            <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div class="btn-group">
                    <button style="width: 50px" type="button" class="btn btn-dark  btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$production['product'][0]['id'].'/1')); ?>'">+</button>
                    <p class="h3 p-2"><?php echo e($production['count']); ?></p>
                    <button style="width:50px" type="button" class="btn btn-dark btn-outline-secondary text-white h3" onclick="window.location.href = '<?php echo e(URL::to('/remove/'.$production['product'][0]['id'])); ?>'">-</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<br>
<h1>Итого: <?php echo e($p); ?></h1>
<button type="button" data-bs-toggle="modal" data-bs-target="#exampleModal" class="btn btn-dark btn-outline-secondary text-white h3">Оформить заказ</button>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Подтверждение заказа</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <h1>Введите пароль</h1>
        <form action="<?php echo e(URL::to('/order/new')); ?>" method="POST">
            <?php echo csrf_field(); ?>

        <div class="form-floating ">
            <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
        </div>

        <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Подтвердить</button>
        </form>
      </div>
    </div>
  </div>
</div>

    </div>
</div>
    <?php else: ?>
    <h2>Добавьте товары в корзину</h2>
    <?php endif; ?>


</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/Korzina.blade.php ENDPATH**/ ?>