<?php $__env->startSection('content'); ?>
<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 250px;">
                    <h4 class="text-center">Название: <?php echo e($genre->name); ?></h4><br>
                    <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/gen/remove/'.$genre->id)); ?>'">Удалить</button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <form class="mt-4" action="<?php echo e(URL::to('/admin/addgenres')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h1>Добавить новый жанр</h1>
            <input class="form-control w-50" type="text"  name="genre_name" required>
            <button class="btn btn-info mt-2" type="submit">Добавить</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/Genres.blade.php ENDPATH**/ ?>