<?php $__env->startSection('content'); ?>
<h1>Девиз: Искусство волнует сердца, театр Омега вдохновляет души.</h1>
<h2 class="text-center">Новые постановки</h2>
<div id="myCarousel" class="carousel slide mb-6 h-100 ms-auto me-auto" style="width:70%;" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-label="Slide 1" aria-current="true"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="3" aria-label="Slide 4" class=""></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="4" aria-label="Slide 5" class=""></button>
    </div>
    <div class="carousel-inner">
        <?php for($i = 0; $i< count($productions); $i++): ?>

        <?php if($i == 0): ?>
            <div class="carousel-item active">
        <?php else: ?>
            <div class="carousel-item">
        <?php endif; ?>
            <img src="<?php echo e(URL::to('/images/'.$productions[$i]->img)); ?>" class="d-block " alt="..." style="width:100%;height:450px">
            <div class="container">
                <div class="carousel-caption text-center text-light">
                    <h1><?php echo e($productions[$i]->name); ?></h1>
                </div>
            </div>
        </div>

        <?php endfor; ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/AboutUs.blade.php ENDPATH**/ ?>