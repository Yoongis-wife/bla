<?php $__env->startSection('content'); ?>

<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->isAdmin == 1): ?>
                <button type="button" class="btn btn-success text-white btn-outline-secondary m-4" onclick="window.location.href = '<?php echo e(URL::to('/admin/addprod')); ?>'">Добавить товар</button>
            <?php endif; ?>
        <?php endif; ?>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <?php $__currentLoopData = $productions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $production): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <div class="card " style="width: 300px;">
                        <a href="<?php echo e(URL::to('catalog/pr/'.$production->id)); ?>"><img src="<?php echo e(url('/images/'.$production->img)); ?>" alt="" style="width:299px"></a>
                        <h4>Название: <?php echo e($production->name); ?></h4>
                        <h5>Цена: <?php echo e($production->price); ?> р.</h5>
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">

                                    <?php if(Auth::check()): ?>
                                        <?php if(Auth::user()->isAdmin==1): ?>
                                            <button type="button" class="btn btn-info text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/changeprod/'.$production->id)); ?>'">Изменить</button>
                                            <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '<?php echo e(URL::to('admin/remove/'.$production->id)); ?>'">Удалить</button>
                                        <?php else: ?>
                                            <?php if($production->count_ticket>0): ?>
                                                <button class="btn btn-primary" onclick="window.location.href = '<?php echo e(URL::to('/add/'.$production->id)); ?>'">Добавить в корзину</button>
                                            <?php else: ?>
                                            <button class="btn btn-secondary"  >Билетов нет в наличии</button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('Layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\teatr\resources\views/Catalog.blade.php ENDPATH**/ ?>