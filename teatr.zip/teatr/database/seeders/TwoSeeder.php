<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
class TwoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('prodgens')->insert([
            [
                'production_id'=>1,
                'genre_id' =>1,
            ],
            [
                'production_id'=>2,
                'genre_id' =>2,
            ],
            [
                'production_id'=>3,
                'genre_id' =>3,
            ],
            [
                'production_id'=>4,
                'genre_id' =>1,
            ],
            [
                'production_id'=>5,
                'genre_id' =>2,
            ],
            [
                'production_id'=>6,
                'genre_id' =>3,
            ],
            [
                'production_id'=>7,
                'genre_id' =>1,
            ],
        ]);

        DB::table('korzinas')->insert([
            [
                'user_id'=>2,
            ],
            [
                'user_id'=>3,
            ],
        ]);


        DB::table('korzinticks')->insert([
            [
                'korzina_id'=>1,
                'production_id'=>1,
                'count'=>2,
                'place'=>'5,6'
            ],
        ]);

        DB::table('orders')->insert([
            [
                'user_id'=>3,
                'status'=>'новый',
            ],
            [
                'user_id'=>2,
                'status'=>'подтвержденый',
            ],
            [
                'user_id'=>3,
                'status'=>'отмененый',
            ],
        ]);

        DB::table('ordticks')->insert([
            [
                'order_id'=>1,
                'production_id'=>3,
                'count'=>1,
                'place'=>'10'
            ],
            [
                'order_id'=>2,
                'production_id'=>6,
                'count'=>2,
                'place'=>'9,6'
            ],
            [
                'order_id'=>3,
                'production_id'=>2,
                'count'=>1,
                'place'=>'17'
            ],
            [
                'order_id'=>3,
                'production_id'=>5,
                'count'=>1,
                'place'=>'20'
            ],
        ]);
    }
}
