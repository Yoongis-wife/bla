<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Carbon\Carbon;
use App\Models\Production;
class MainSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'name'=>'Алена',
                'surname'=> 'Никифорова',
                'patronymic'=> 'Андреевна',
                'login'=>'admin',
                'email'=>'niki@gmail.com',
                'password'=>Hash::make('admin33'),
                'isAdmin'=>1,
            ],
            [
                'name'=> Str::random(10),
                'surname'=>Str::random(10),
                'patronymic'=> Str::random(10),
                'login'=>Str::random(10),
                'email'=>Str::random(10).'@gmail.com',
                'password'=>Hash::make('password'),
                'isAdmin'=>0,
            ],
            [
                'name'=> Str::random(10),
                'surname'=>  Str::random(10),
                'patronymic'=>  Str::random(10),
                'login'=>Str::random(10),
                'email'=>Str::random(10).'@gmail.com',
                'password'=>Hash::make('user36'),
                'isAdmin'=>0,
            ],
        ]);

        DB::table('genres')->insert([
            [
              'name' =>'комедии',
            ],
            [
                'name' => 'драмы',
            ],
            [
                'name' => 'мистерия',
            ],
        ]);

    for ($i=0; $i < 7; $i++) { 


        Production::create([
            
                'name' =>Str::random(10),
                'img'=>rand(1,7) . '.jpg',
                'show_date'=>Carbon::now()->addDays(rand(0,30))->format('Y-m-d'),
                'age_limit'=>fake()->randomElement(['0', '6', '12', '16', '18']),
                'price'=>rand(300, 1000),
                'count_ticket'=>rand(1,10),
              
        ]);

    }
   
        

        
    }
}
