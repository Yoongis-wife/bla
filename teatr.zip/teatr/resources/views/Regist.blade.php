@extends('Layout')
@section('content')
<div class="d-flex align-items-center py-4 bg-body-tertiary m-0 h-100">
    <main class="form-signin w-50 m-auto p-5">
  <form method="POST" action="{{URL::to('/register')}}">
     <!-- onsubmit="event.preventDefault();Validate();"> -->
    <H1>Форма регистрации</H1>
    @csrf
    <div class="form-floating m-2">
      <input class="form-control" id="floatingInput surname" placeholder="Surname" name="surname" required>
      <label for="floatingInput">Surname</label>
    </div>
    <div class="form-floating m-2">
      <input class="form-control" id="floatingInput name" placeholder="Name" name="name" required>
      <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
      <input class="form-control" id="floatingInput" placeholder="Patronymic" name="patr">
      <label for="floatingInput">Patronymic</label>
    </div>
    <div class="form-floating m-2">
        <input required type="email" class="form-control" id="floatingInput email" placeholder="name@example.com" name="email">
        <label for="floatingInput">Email address</label>
    </div>
    <div class="form-floating m-2">
      <input required class="form-control" id="floatingInput login" placeholder="Login" name="login">
      <label for="floatingInput">Login</label>
    </div>
    <div class="form-floating m-2">
      <input required type="password" class="form-control password" id="floatingPassword " placeholder="Password" name="password">
      <label for="floatingPassword">Password</label>
    </div>
    <div class="form-floating m-2">
      <input required type="password" class="form-control rpassword" id="floatingPassword d" placeholder="Password" name="password_repeat">
      <label for="floatingPassword">Reapet password</label>
    </div>
    <div class="m-2">
        <input required type="checkbox" class=" rules" id="floatingPassword" name="rules">
      <label for="floatingPassword">Я согласен с условиями политики конфиденциальности</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Зарегистрироваться</button>
  </form>
    </main>
</div>

<!-- <script src="../public/sign.js"/> -->
@endsection
@show
