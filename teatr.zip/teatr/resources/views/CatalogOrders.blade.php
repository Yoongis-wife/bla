@extends('Layout')
@section('content')
@if (Auth::check())
    @if (Auth::user()->isAdmin == 0)
<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach ($orders as $order)
            <div class="col">
                <div class="card " style="width: 200px;">
                    <h4 class="text-center">Заказ № {{$order['order']->id}}</h4><br>
                    @foreach ($order['productions'] as $prod )
                        <p>Постановка: {{$prod['production']->name}}</p>
                        <p>Количество билетов:  {{$prod['count']}}</p>
                    @endforeach
                    <p>Статус: {{$order['order']->status}}</p>
                    @if($order['order']->status == 'новый')
                    <button type="button" class="btn btn-danger text-white btn-outline-secondary " onclick="window.location.href = '{{URL::to('order/remove/'.$order['order']->id)}}'">Удалить</button>
                    @endif
                </div>
            </div>
        @endforeach
            </div>
        </div>
    </div>
</div>

@else
<div class="album py-5 bg-body-tertiary">
    <div class="container">

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach ($orders as $order)
            <div class="col">
                <div class="card " style="width: 300px;">
                    <h4 class="text-center">Заказ № {{$order['order']->id}}</h4><br>
                    <h4 class="text-start">Заказчик: {{$order['user']->name}} {{$order['user']->surname}} {{$order['user']->patronymic}}</h4><br>
                    @foreach ($order['productions'] as $prod )
                        <p>Постановка: {{$prod['production']->name}}</p>
                        <p>Количество билетов:  {{$prod['count']}}</p>
                    @endforeach
                    <p>Статус: {{$order['order']->status}}</p>
                    <p>Дата создания: {{$order['order']->created_at}}</p>
                    @if($order['order']->status == 'новый')
                    <form action="{{URL::to('/admin/changestatus/'.$order['order']->id)}}" method="POST">
                        @csrf
                        <select name="status" id="">
                            <option value="0">Выберете статус</option>
                            <option value="подтвержденный">подтвержденный</option>
                            <option value="отмененый">отмененый</option>
                        </select>
                        <button type="submit" class="btn btn-info text-white btn-outline-secondary " >Изменить</button>
                    </form>
                    @endif
                </div>
            </div>
        @endforeach
            </div>
        </div>
    </div>
</div>
@endif
@endif
@endsection
@show
