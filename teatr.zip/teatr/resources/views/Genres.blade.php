@extends('Layout')
@section('content')
<div class="album py-5 bg-body-tertiary">
    <div class="container">
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        @foreach ($genres as $genre)
            <div class="col">
                <div class="card " style="width: 250px;">
                    <h4 class="text-center">Название: {{$genre->name}}</h4><br>
                    <button type="button" class="btn btn-danger text-white btn-outline-secondary" onclick="window.location.href = '{{URL::to('admin/gen/remove/'.$genre->id)}}'">Удалить</button>
                </div>
            </div>
        @endforeach
            </div>
        </div>

        <form class="mt-4" action="{{URL::to('/admin/addgenres')}}" method="POST">
            @csrf
            <h1>Добавить новый жанр</h1>
            <input class="form-control w-50" type="text"  name="genre_name" required>
            <button class="btn btn-info mt-2" type="submit">Добавить</button>
        </form>
    </div>
</div>
@endsection
@show
