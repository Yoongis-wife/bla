@extends('Layout')
@section('content')

@if(isset($production))
<form method="POST" action="{{URL::to('/admin/changeprod/'.$production->id)}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Изменить постановку</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="{{$production->name}}" placeholder="name">
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="{{$production->show_date}}" placeholder="Date">
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img">
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="{{$production->age_limit}}" placeholder="Date">
        <label for="floatingPassword">Age limit</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="{{$production->price}}" placeholder="Date">
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="{{$production->count_ticket}}" placeholder="Date">
        <label for="floatingPassword">Count ticket</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Выберете жанр</option>
            @foreach ($genres as $genre)
            <option value="{{$genre->id}}" @if($curgenre->id == $genre->id ) @selected(true) @endif>{{$genre->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Genre</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Change</button>
</form>
@else
<form method="POST" action="{{URL::to('/admin/addprod')}}" class="w-50 m-auto" enctype="multipart/form-data">
    @csrf
    <h1 class="h3 mb-3 fw-normal">Добавить новый продукт</h1>

    <div class="form-floating m-2">
        <input name="name" class="form-control" id="floatingInput" value="" placeholder="name" required>
        <label for="floatingInput">Name</label>
    </div>
    <div class="form-floating m-2">
        <input type="date" name="date" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Date</label>
    </div>
    <div class="form-floating m-2">
        <input type="file" name="file" class="form-control" id="floatingPassword" accept="image/png, image/jpeg" placeholder="Img" required>
        <label for="floatingPassword">Image</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="limit" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Age limit</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="price" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Price</label>
    </div>
    <div class="form-floating m-2">
        <input type="number" name="count" class="form-control" id="floatingPassword" value="" placeholder="Date" required>
        <label for="floatingPassword">Count ticket</label>
    </div>
    <div class="form-floating m-2">
        <select name="genre" class="form-select">
            <option value="0">Выберете жанр</option>
            @foreach ($genres as $genre)
            <option value="{{$genre->id}}">{{$genre->name}}</option>
            @endforeach
        </select>
        <label for="floatingPassword">Genre</label>
    </div>
    <button class="btn btn-primary w-100 py-2 m-auto" type="submit">Add</button>
</form>

@endif



@endsection
@show
