@extends('Layout')
@section('content')

<div class="justify-content-center row w-75 m-auto">
    <div class="col">
        <img src="../../images/{{$production->img}}" style="width:400px">
    <div class="col">
        <h1>Название: {{$production->name}}</h1>
        <p>Дата показа: {{$production->show_date}}</p>
        <p>Возрастной ценз: {{$production->age_limit}}+</p>
        <p>Цена: {{$production->price}}</p>
        <p>Жанр: {{$genre[0]}}</p>
        @if (Auth::check())
            @if($production->count_ticket>0)
                <button class="btn btn-primary" onclick="window.location.href = '{{URL::to('/add/'.$production->id)}}'">Добавить в корзину</button> 
            @endif
        @endif
    </div>
</div>

@endsection
@show
