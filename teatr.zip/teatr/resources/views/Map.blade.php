@extends('Layout')
@section('content')
    <div class="m-5 row">
        <div class="col">
            <img src="{{URL::to('/images/map.jpg')}}" class="d-block " alt="..." style="width:100%;height:450px">
        </div>
        <div class="col">
            <strong><p class="m-2">Адрес: г.Каменск- ул.Тевосяна д.5</p></strong>
            <strong><p class="m-2">Контактный телефон: +7-800-535-35-35</p></strong>
            <strong><p class="m-2">Эл. почта: niki@mail.ru</p></strong>
        </div>

    </div>
@endsection
@show
