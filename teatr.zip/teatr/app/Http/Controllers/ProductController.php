<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Production;
use App\Models\Genre;
use App\Models\Prodgen;
class ProductController extends Controller
{
    public function All($s=null, $p=null){
        $productions = [];
        $productions = Production::orderBy('created_at')->get();
        return view('Catalog',['productions'=>$productions]);
    }

    public function One($id){
        return view('Product',['production'=>Production::find($id), 'genre'=>Genre::find(Prodgen::where('production_id',$id)->pluck('genre_id'))->pluck('name')]);
    }

    public function About(){
        $productions = Production::orderByDesc('show_date')->take(5)->get()->sort();
        return view('AboutUs', ['productions'=>$productions]);
    }
}
