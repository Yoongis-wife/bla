<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Production;
use App\Models\Korzina;
use App\Models\Korzintick;

class UserController extends Controller
{

    public function Regist(Request $request){

        $validateFiels = $request->validate([
                'name'=>'required',
                'surname'=>'required',
                'patr'=>'string',
                'login'=>'required',
                'email'=>'required|email',
                'password'=>'required',
        ]);

        $user = User::where(['login'=>$validateFiels['login'],'email'=>$validateFiels['email']])->first();
        if (!$user) {
            $user = User::create([
                'name'=>$validateFiels['name'],
                'surname'=>$validateFiels['surname'],
                'patronymic'=>$validateFiels['patr'],
                'login'=>$validateFiels['login'],
                'email'=>$validateFiels['email'],
                'password'=>$validateFiels['password'],
                'isAdmin'=>0,
            ]);
            Auth::login($user);
            Korzina::create([
                'user_id'=>Auth::id(),
            ]);
            return redirect('/catalog');
        }
        return redirect('/register');
    }

    public function Auth(Request $request){
        $foundFields = $request->only(['login','password']);

        if(Auth::attempt($foundFields))
        {
            if (Auth::user()->isAdmin==1) {
                return redirect('/admin');
            }
            return redirect('/catalog');
        }
        return redirect('/login');
    }

    public function GetKorzina(){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['user_id'=>$user->id])->first();
            $productions = [];
            $kp = Korzintick::where(['korzina_id'=>$korz->id])->get();
            $p=0;
            foreach ($kp as $k) {
                $pr = Production::where('id',$k->production_id)->get();
                $p+= $pr[0]->price*$k->count;
                array_push($productions,['product'=>$pr->toArray(), 'count'=>$k->count]);
            }
            return view('Korzina',['productions'=>$productions,'p'=>$p]);
        }

    }

    public function AddToKorzina($id, $c=null){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['user_id'=>$user->id])->first();
            if (Korzintick::where(['korzina_id'=>$korz->id, 'production_id'=>$id])->first()===null) {
                $kp = Korzintick::where(['korzina_id'=>$korz->id, 'production_id'=>$id])->get();
                $product = Production::find($id);
                if($product->count_ticket!=0)
                {
                    Korzintick::create(['production_id'=>$product->id, 'korzina_id'=>$korz->id,'place'=>'1', 'count'=>1]);
                    $product=Production::find($id)->decrement('count_ticket', 1);
                }
            }
            else {
                $product = Production::find($id);
                if($product->count_ticket!=0)
                {
                    $kp = Korzintick::where(['korzina_id'=>$korz->id, 'production_id'=>$id])->first();
                    $kp->count++;
                    $kp->save();
                    $product=Production::find($id)->decrement('count_ticket', 1);
                }
            }
            if ($c==null) {
                return redirect('/catalog');
            }
            return redirect('/korzina');

        }
    }

    public function RemoveFromKorzina($id){
        if (Auth::check()) {
            $user = Auth::user();
            $korz = Korzina::where(['user_id'=>$user->id])->first();
            $kp=Korzintick::where('korzina_id', $korz->id)->where('production_id', $id)->first();
            $kp=Korzintick::where('korzina_id', $korz->id)->where('production_id', $id)->decrement('count', 1);
            $product = Production::find($id);
            $product=Production::find($id)->increment('count_ticket', 1);
            $count=Korzintick::where('korzina_id', $korz->id)->where('production_id', $id)->first()->toArray()['count'];
            if ($count<1) {
                $kp=Korzintick::where('korzina_id', $korz->id)->where('production_id', $id)->first();
                $kp->delete();
            }
            return redirect('/korzina');
        }
    }

}
