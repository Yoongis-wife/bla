<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Korzina extends Model
{
    public function korzinticks(): HasMany
    {
        return $this->hasMany(Korzintick::class);
    }
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
    use HasFactory;
    protected $fillable = [
        'user_id',
    ];
}
