<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class Korzintick extends Model
{
    public function korzina(): BelongsTo
    {
        return $this->belongsTo(Korzina::class);
    }
    public function production(): BelongsTo
    {
        return $this->belongsTo(Production::class);
    }
    use HasFactory;
    protected $fillable = [
        'korzina_id',
        'production_id',
        'count',
        'place',
    ];
}
